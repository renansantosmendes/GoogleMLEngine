import argparse
import docopt
import model  # Your model.py file.

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # Input Arguments
    parser.add_argument(
        '--train_data_paths',
        help = 'GCS or local path to training data',
        required = True
    )
    parser.add_argument(
        '--output_dir',
        help = 'GCS location to write checkpoints and export models',
        required = True
    )
    args = parser.parse_args()
    # Assign model variables to commandline arguments
    model.TRAIN_PATHS = args.train_data_paths
    model.BATCH_SIZE = args.batch_size
    
    # Run the training job
    model.train_and_evaluate()