import argparse
import docopt
import model  # Your model.py file.

if __name__ == '__main__':
    parser = argparse.ArgumentParser()       
    # Run the training job
    model.train_and_evaluate()