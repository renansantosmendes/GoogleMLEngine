from docopt import docopt

import model  # Your model.py file.

if __name__ == '__main__':
	arguments = docopt(__doc__)
	# Assign model variables to commandline arguments
	model.TRAIN_PATHS = arguments['<train_data_paths>']
	model.OUTPUT_DIR = arguments['<outdir>']
	model.train_and_evaluate()