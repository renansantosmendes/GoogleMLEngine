"""Run a training job on Cloud ML Engine for a given use case.
Usage:
  trainer.task 
Options:
  -h --help     Show this screen.  
"""
from docopt import docopt

import model  # Your model.py file.

if __name__ == '__main__':
    arguments = docopt(__doc__)
    # Assign model variables to commandline arguments
    # Run the training job
    model.train_and_evaluate()
